import Logo from '../Images/Onwork Logo.png';
function CompanyLogo()
{
    return(
        <>
           <div className='w-40 h-40  '>
                <img src={Logo} alt="" className=' h-fauto w-full  ' />
            </div>
        </>
    )
}


export default CompanyLogo