function GoodMorningUser()
{
    return(
        <>
        <h1 className=' font-medium xl:text-2xl text-white text-nowrap text-lg'>Good Morning, Sohail Ansari</h1>
        </>
    )
}

export default GoodMorningUser