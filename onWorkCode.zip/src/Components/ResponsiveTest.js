function Responsive() {
    return <>

        <div>
            <p >Good Morning</p>
            <p >Good Morning</p>
            <div className="md:bg-red-600 md lg:bg-blue-700 xl:bg-yellow-800">
                <p >Good Morning</p>
                <div >
                    <p className="text-blue-700">Good Morning</p>
                </div>
            </div>
        </div>
    </>
}

export default Responsive